# Desain Cilik

Starter template untuk website jualan template digital.

## Cara Deploy ke GitHub Pages

1. Buat repository `username.github.io`.
2. Push seluruh folder `desain_cilik_starter` ke branch `main`.
3. GitHub Pages otomatis live di `https://username.github.io`.

Enjoy! 🎉
